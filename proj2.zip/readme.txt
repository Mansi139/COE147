COEmips project-2

Main- main program
RegisterFile - 8 registers
ALUnew - 32 bit ALU
RorI,RorIcontrol,R/I/Load/store - control
Decoder- takes 32 bit input and accoring to opcode,sets correct signals
Rcontrol,Icontrol - control to chose from R and I format instructions
MainControl- main control unit
